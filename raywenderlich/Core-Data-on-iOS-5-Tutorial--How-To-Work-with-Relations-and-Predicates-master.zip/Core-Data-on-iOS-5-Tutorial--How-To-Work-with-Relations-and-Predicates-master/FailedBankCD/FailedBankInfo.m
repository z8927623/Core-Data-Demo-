//
//  FailedBankInfo.m
//  FailedBankCD
//
//  Created by cesarerocchi on 5/22/12.
//  Copyright (c) 2012 Adam Burkepile. All rights reserved.
//

#import "FailedBankInfo.h"
#import "FailedBankDetails.h"


@implementation FailedBankInfo

@dynamic city;
@dynamic name;
@dynamic state;
@dynamic details;

@end
