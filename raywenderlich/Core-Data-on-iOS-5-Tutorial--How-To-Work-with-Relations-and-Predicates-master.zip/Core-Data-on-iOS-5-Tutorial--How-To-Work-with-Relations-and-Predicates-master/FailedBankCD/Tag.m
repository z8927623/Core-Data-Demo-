//
//  Tag.m
//  FailedBankCD
//
//  Created by cesarerocchi on 5/22/12.
//  Copyright (c) 2012 Adam Burkepile. All rights reserved.
//

#import "Tag.h"
#import "FailedBankDetails.h"


@implementation Tag

@dynamic name;
@dynamic detail;

@end
