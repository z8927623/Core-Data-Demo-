//
//  FailedBankDetails.m
//  FailedBankCD
//
//  Created by cesarerocchi on 5/22/12.
//  Copyright (c) 2012 Adam Burkepile. All rights reserved.
//

#import "FailedBankDetails.h"
#import "FailedBankInfo.h"
#import "Tag.h"


@implementation FailedBankDetails

@dynamic closeDate;
@dynamic updateDate;
@dynamic zip;
@dynamic info;
@dynamic tags;

@end
