//
//  asyncCoreDataWrapper.h
//  asyncCoreDataWrapper
//
//  Created by LiMing on 14-10-16.
//  Copyright (c) 2014年 liming. All rights reserved.
//

#ifndef asyncCoreDataWrapper_asyncCoreDataWrapper_h
#define asyncCoreDataWrapper_asyncCoreDataWrapper_h
#import "mmDAO.h"
#import "NSManagedObject+helper.h"

#endif
