//
//  Entity.m
//  asyncCoreDataWrapper
//
//  Created by LiMing on 14-6-26.
//  Copyright (c) 2014年 liming. All rights reserved.
//

#import "Entity.h"


@implementation Entity

@dynamic task_id;
@dynamic title;
@dynamic detail;
@dynamic done;

@end
