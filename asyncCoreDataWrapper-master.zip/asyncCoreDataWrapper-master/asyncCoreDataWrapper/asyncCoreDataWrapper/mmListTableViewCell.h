//
//  mmListTableViewCell.h
//  asyncCoreDataWrapper
//
//  Created by LiMing on 14-6-25.
//  Copyright (c) 2014年 liming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mmListTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lbText;
@end
