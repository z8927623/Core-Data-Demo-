//
//  mmContentViewController.h
//  asyncCoreDataWrapper
//
//  Created by LiMing on 14-6-26.
//  Copyright (c) 2014年 liming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Entity.h"

@interface mmContentViewController : UIViewController
@property (nonatomic, strong) Entity *entity;
@end
