//
//  main.m
//  asyncCoreDataWrapper
//
//  Created by LiMing on 14-6-25.
//  Copyright (c) 2014年 liming. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "mmAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([mmAppDelegate class]));
    }
}
