//
// Created by chris on 6/16/13.
//

#import <Foundation/Foundation.h>

@interface NSString (ParseCSV)
- (NSArray*)csvComponents;
@end