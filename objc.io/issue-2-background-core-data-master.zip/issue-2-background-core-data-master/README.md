objc.io issue #2
===

This is an example project for the article [Common Background Practices](http://www.objc.io/issue-2/common-background-practices.html) published in [objc.io issue #2](http://www.objc.io/issue-2/index.html).
