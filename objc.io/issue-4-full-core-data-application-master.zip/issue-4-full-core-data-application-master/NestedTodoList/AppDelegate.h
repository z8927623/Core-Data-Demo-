//
//  AppDelegate.h
//  NestedTodoList
//
//  Created by Chris Eidhof on 8/13/13.
//  Copyright (c) 2013 Chris Eidhof. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Store;
@class PersistentStack;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
