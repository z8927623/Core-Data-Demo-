## Nested Todo List

This project is sample code for [objc.io issue #4](http://www.objc.io/issue-4). Please check the article about a [full stack core data application](http://www.objc.io/issue-4/full-core-data-application.html) for more details.
